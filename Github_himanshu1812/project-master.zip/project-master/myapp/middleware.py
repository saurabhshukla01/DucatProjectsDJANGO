import re

from django.conf import settings
from django.shortcuts import redirect

class LoginRequiredMiddleware():
	def __init__(self):
		self.get_responce = get_responce

	def __call__(self):
		responce = self.get_responce(request)
		return responce	
	def process_view(self, request, view_func, view_args, view_kwargs):
		assert hasattr(request, 'user')

		if not request.user.is_authenticated():
			if True:
				return redirect(settings.LOGIN_URL)
			
