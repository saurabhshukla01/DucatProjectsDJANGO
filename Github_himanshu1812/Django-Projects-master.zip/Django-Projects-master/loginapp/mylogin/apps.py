from django.apps import AppConfig


class MyloginConfig(AppConfig):
    name = 'mylogin'
