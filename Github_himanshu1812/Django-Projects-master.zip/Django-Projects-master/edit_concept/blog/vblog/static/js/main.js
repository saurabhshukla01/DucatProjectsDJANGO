
$('#source').quicksand( $('#destination li') );