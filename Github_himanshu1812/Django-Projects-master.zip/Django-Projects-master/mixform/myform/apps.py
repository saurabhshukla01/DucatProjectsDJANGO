from django.apps import AppConfig


class MyformConfig(AppConfig):
    name = 'myform'
#C:\Users\himanshu\AppData\Local\Programs\Python\Python37-32\Scripts
#C:\Users\himanshu\AppData\Local\Programs\Python\Python37-32\