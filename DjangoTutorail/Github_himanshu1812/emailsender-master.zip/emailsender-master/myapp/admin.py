from django.contrib import admin
from .models import *
admin.site.register(Emp)
admin.site.register(Empl)
# Register your models here.
