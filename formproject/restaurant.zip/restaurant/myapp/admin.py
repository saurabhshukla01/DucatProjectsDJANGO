from django.contrib import admin
from .models import *
admin.site.register(Restaurant)
admin.site.register(Dish)    
# Register your models here.
